enum GameMode { daily, lvl }
