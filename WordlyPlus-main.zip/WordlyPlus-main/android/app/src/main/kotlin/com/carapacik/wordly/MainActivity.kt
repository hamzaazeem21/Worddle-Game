package com.carapacik.wordly

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
